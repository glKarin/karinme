ln -s /usr/bin/java ${datadir}/Java
chmod a+x ${datadir}/MicroEmulator